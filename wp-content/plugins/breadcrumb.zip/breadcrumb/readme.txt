=== Breadcrumb ===
	Contributors: paratheme
	Donate link: http://paratheme.com/donate-us/
	Tags: breadcrumb, breadcrumbs
	Requires at least: 3.8
	Tested up to: 4.2
	Stable tag: 1.2
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Super light weight & easy Breadcrumb for wordpress site

== Description ==

Breadcrumb is awesome feature for visitors keep track thier location, by this plugin you can display Breadcrumb navigation anywhere your website via short-codes.



### Breadcrumb by http://paratheme.com

* [Buy Premium! &raquo;](http://paratheme.com/items/breadcrumb-awesome-breadcrumbs-style-navigation-for-wordpress/)

<br />


<strong>Plugin Features</strong><br />

* Use via short-codes.
* Custom Separator text.
* Custom text in-front of Breadcrumb.
* Breadcrumb display on home page, any post type, page, parent pages, author page, archive page, tag page, custom taxonomy page, search page, 404 error page, 







== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>Breadcrumb</strong>" activate it.<br />

After activate plugin you will see "Breadcrumb" menu at left side on WordPress dashboard<br />

<br />
<strong>How to display breadcrumb ?</strong><br />

use this short-code any where to display breadcrumb
`[breadcrumb]`








== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3
4. screenshot-4



== Changelog ==

	= 1.2 =
    * 03/04/2015 - add - unlimited depth parent page link on breadcrumb.
	
	= 1.1 =
    * 23/03/2015 - add - parent page link on breadcrumb.
	
	= 1.0 =
    * 27/10/2014 Initial release.
