jQuery(document).ready(function($)
	{



	});