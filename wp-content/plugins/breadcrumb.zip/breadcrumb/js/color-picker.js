	jQuery(document).ready(function(jQuery)
		{	


			jQuery('.breadcrumb_link_color, .breadcrumb_separator_color').wpColorPicker();
					
					


		});